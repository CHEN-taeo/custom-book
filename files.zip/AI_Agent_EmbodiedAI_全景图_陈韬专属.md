# AI × 智能体 × 具身智能：未来技能与资源全景图

> **陈韬专属版 · v1.0 · 2026.06**  
> 覆盖方向：强化学习 → 多智能体（MARL）→ LLM Agent → 具身智能 → VLA 基础模型  
> 你现在的位置：DQN/CartPole ✅ → **MARL/PettingZoo（当前下一步）**

---

## 🗺️ 学习路线总图

```mermaid
graph TD
    A["📐 数学基础\n线代·概率论·凸优化"] --> B["⚡ 深度学习\nPyTorch·CNN·Transformer"]
    B --> C["🎮 强化学习 RL\nQ-Learning→DQN→PPO→SAC"]

    C --> D{"🔀 三条主线"}

    D --> E["👥 多智能体 MARL\nPettingZoo·MADDPG·QMIX·MAPPO"]
    D --> F["🤖 LLM Agent\nReAct·Reflexion·RAG·Tool Use"]
    D --> G["🦾 具身控制\nMuJoCo·IsaacLab·仿真→真机"]

    E --> H["🌐 VLA基础模型\nRT-2·OpenVLA·π₀·Diffusion Policy"]
    F --> H
    G --> H

    H --> I["🔬 前沿融合\n具身MARL·World Model·神经符号AI"]

    I --> J["🎯 你的终局\n多智能体具身系统·老年护理机器人"]

    style A fill:#2d4a7a,color:#fff
    style J fill:#7a2d2d,color:#fff
    style I fill:#2d6b3a,color:#fff
    style H fill:#4a4a2d,color:#fff
```

---

## 模块一：核心知识体系

### 1.1 奠基性论文

#### 深度学习与序列模型

| 论文名称 | 作者/年份 | 核心贡献 | 获取 | 难度 |
|---------|---------|---------|-----|------|
| Deep Learning (综述) | LeCun, Bengio, Hinton · 2015 | 三巨头写给 Nature 的 DL 全景：BP、CNN、RNN 一次讲透 | [DOI:10.1038/nature14539](https://doi.org/10.1038/nature14539) | 入门 |
| Attention Is All You Need | Vaswani et al. · 2017 | Transformer 架构诞生，现代 LLM/VLA 之根 | [arXiv:1706.03762](https://arxiv.org/abs/1706.03762) | 入门 |
| BERT | Devlin et al. · 2018 | 双向预训练范式，NLP 革命起点 | [arXiv:1810.04805](https://arxiv.org/abs/1810.04805) | 入门 |
| GPT-3 | Brown et al. · 2020 | Few-shot 涌现能力，LLM 时代正式开启 | [arXiv:2005.14165](https://arxiv.org/abs/2005.14165) | 进阶 |
| InstructGPT | Ouyang et al. · 2022 | RLHF 对齐：从预训练到"好用"的关键跨越 | [arXiv:2203.02155](https://arxiv.org/abs/2203.02155) | 进阶 |

#### 强化学习核心算法

| 论文名称 | 作者/年份 | 核心贡献 | 获取 | 难度 |
|---------|---------|---------|-----|------|
| Playing Atari with DRL | Mnih et al., DeepMind · 2015 | **你已复现**：DQN，神经网络函数近似 RL 第一次成功 | [DOI:10.1038/nature14236](https://doi.org/10.1038/nature14236) | 入门 ✅ |
| Proximal Policy Optimization (PPO) | Schulman et al. · 2017 | 当前最广泛使用的 on-policy 算法，稳定好调 | [arXiv:1707.06347](https://arxiv.org/abs/1707.06347) | 进阶 |
| Soft Actor-Critic (SAC) | Haarnoja et al. · 2018 | 最大熵框架，连续控制最稳定的 off-policy 算法 | [arXiv:1801.01290](https://arxiv.org/abs/1801.01290) | 进阶 |
| A3C | Mnih et al. · 2016 | 并行异步 Actor-Critic，理解多线程 RL 的入门 | [arXiv:1602.01783](https://arxiv.org/abs/1602.01783) | 进阶 |
| TD3 | Fujimoto et al. · 2018 | 双延迟确定性策略，SAC 的确定性替代 | [arXiv:1802.09477](https://arxiv.org/abs/1802.09477) | 进阶 |

#### 多智能体强化学习（MARL）—— 你的下一主战场

| 论文名称 | 作者/年份 | 核心贡献 | 获取 | 难度 |
|---------|---------|---------|-----|------|
| MADDPG | Lowe et al., OpenAI · 2017 | **集中训练、分布执行（CTDE）范式奠基，读懂它才能读懂后续一半 MARL 论文** | [arXiv:1706.02275](https://arxiv.org/abs/1706.02275) | 进阶 |
| QMIX | Rashid et al. · 2018 | 值函数分解，StarCraft 多智能体测试床的代表 | [arXiv:1803.11605](https://arxiv.org/abs/1803.11605) | 进阶 |
| MAPPO | Yu et al. · 2021 | PPO 在 MARL 中的正确应用方式，上手首选 | [arXiv:2103.01955](https://arxiv.org/abs/2103.01955) | 进阶 |
| QPLEX | Wang et al. · 2020 | QMIX 的改进：完全因子化值函数分解 | [arXiv:2008.01062](https://arxiv.org/abs/2008.01062) | 前沿 |

#### 具身智能与机器人基础

| 论文名称 | 作者/年份 | 核心贡献 | 获取 | 难度 |
|---------|---------|---------|-----|------|
| SayCan | Ahn et al., Google · 2022 | LLM 规划 + RL 执行可行性打分，语言与机器人结合的范式 | [arXiv:2204.01691](https://arxiv.org/abs/2204.01691) | 进阶 |
| RT-1 | Brohan et al., Google · 2022 | 大规模机器人操控 Transformer，13 万次演示训练 | [arXiv:2212.06817](https://arxiv.org/abs/2212.06817) | 进阶 |
| Gato | Reed et al., DeepMind · 2022 | 单一网络 600+ 任务的通用 Agent，多任务泛化的开山 | [arXiv:2205.06175](https://arxiv.org/abs/2205.06175) | 进阶 |
| World Models | Ha & Schmidhuber · 2018 | 在大脑内"做梦"训练，世界模型范式原点 | [arXiv:1803.10122](https://arxiv.org/abs/1803.10122) | 进阶 |
| DreamerV3 | Hafner et al. · 2023 | 单一超参跨 Atari/连续控制/机器人，零调参世界模型 | [arXiv:2301.04104](https://arxiv.org/abs/2301.04104) | 前沿 |

---

### 1.2 2024–2025 顶会 / 高影响力论文

| 论文名称 | 来源/年份 | 核心贡献 | 获取 | 难度 |
|---------|---------|---------|-----|------|
| RT-2 | CoRL 2023, Google | **VLA 里程碑**：视觉语言模型直接输出机器人动作指令 | [arXiv:2307.15818](https://arxiv.org/abs/2307.15818) | 前沿 |
| PaLM-E | ICML 2023, Google | 562B 参数具身多模态 LLM，感知→推理→行动一体化 | [arXiv:2303.03378](https://arxiv.org/abs/2303.03378) | 前沿 |
| Diffusion Policy | RSS 2023 | 扩散模型用于机器人操控，彻底改变了操控策略的建模方式 | [arXiv:2303.04137](https://arxiv.org/abs/2303.04137) | 前沿 |
| OpenVLA | CoRL 2024 | **开源 VLA 基准**，7B 参数可在消费级 GPU 上微调 | [arXiv:2406.09246](https://arxiv.org/abs/2406.09246) | 前沿 |
| π₀ (Pi Zero) | Physical Intelligence · 2024 | 首个通用机器人基础模型，流匹配策略，跨机器人迁移 | [arXiv:2410.24164](https://arxiv.org/abs/2410.24164) ⚠️待验证ID | 前沿 |
| ReAct | ICLR 2023 | 推理（Reasoning）+ 行动（Acting）交替框架，LLM Agent 标配 | [arXiv:2210.03629](https://arxiv.org/abs/2210.03629) | 进阶 |
| Reflexion | NeurIPS 2023 | 语言反射让 Agent 从错误中自我进化，你的 Echo/JieZi 直接相关 | [arXiv:2303.11366](https://arxiv.org/abs/2303.11366) | 进阶 |
| I-JEPA | CVPR 2023 | LeCun 路线：图像联合嵌入预测，离开像素重建的感知范式 | [arXiv:2301.08243](https://arxiv.org/abs/2301.08243) | 前沿 |
| Decision Transformer | NeurIPS 2021 | RL 即序列建模，用 GPT 架构解 RL 问题的范式转移 | [arXiv:2106.01345](https://arxiv.org/abs/2106.01345) | 进阶 |
| RoboAgent | CoRL 2023 | 语义增强迁移，少量演示做通用机器人操控 | [arXiv:2309.01918](https://arxiv.org/abs/2309.01918) ⚠️待验证 | 前沿 |

> ⚠️ **标注说明**：π₀ 论文 arXiv ID 建议直接搜索 `"Physical Intelligence pi zero robot 2024"` 确认；标注「待验证」的资源请自行核查最新状态。

---

### 1.3 高质量综述（Survey）

| 综述名称 | 作者/年份 | 覆盖范围 | 获取 | 难度 |
|---------|---------|---------|-----|------|
| A Survey on LLM-based Autonomous Agents | Wang et al. · 2023 | Agent 规划/记忆/工具调用/应用全景，**入门 Agent 必读** | [arXiv:2308.11432](https://arxiv.org/abs/2308.11432) | 入门 |
| The Rise and Potential of LLM-based Agents | Xi et al. · 2023 | Agent 能力边界、挑战与未来，互补上一篇 | [arXiv:2309.07864](https://arxiv.org/abs/2309.07864) | 入门 |
| A Survey of Embodied AI (2022) | Duan et al. | 具身 AI 全景：感知/交互/仿真环境/学习范式 | [arXiv:2103.04918](https://arxiv.org/abs/2103.04918) | 进阶 |
| Foundation Models for Robotics | Hu et al. · 2023 | 机器人基础模型综述，VLA 的上下文 | [arXiv:2312.07843](https://arxiv.org/abs/2312.07843) ⚠️待验证 | 前沿 |
| Cooperative Multi-Agent Learning | 搜索关键词 | MARL 合作方向综述，与你 MARL 路线直接相关 | 搜索 `"cooperative MARL survey 2023"` | 进阶 |

---

### 1.4 关键技术演进脉络

**强化学习主脉络（你的当前主线）**
```
Q-Learning (Watkins 1992) → 理论基础
  └→ DQN (Mnih 2015) ✅ 你已完成：神经网络函数近似
       └→ A3C (2016)：并行异步
            └→ PPO (2017)：稳定 on-policy，最广泛使用
                 └→ SAC (2018)：最大熵 off-policy，连续控制
                      └→ Decision Transformer (2021)：RL = 序列建模
                           └→ 当前前沿：GRPO · 扩散策略 · 世界模型 RL

并行线（你的下一步）：
  MADDPG (2017) → QMIX (2018) → MAPPO (2021) → 当前 MARL 前沿
```

**具身智能演进**
```
传统控制 (PID/MPC) → 物理规则约束
  └→ 深度 RL 控制 (2016-2019)：端到端学习
       └→ 模仿学习 + 演示数据 (2020-2021)
            └→ LLM 任务规划 (SayCan 2022)：语言作为接口
                 └→ VLA 视觉语言动作模型 (RT-2 2023)
                      └→ 通用机器人基础模型 (π₀ 2024)
                           └→ 当前前沿：数据引擎 · 世界模型预训练 · 人形机器人
```

**世界模型演进**
```
World Models (Ha & Schmidhuber 2018) → 在潜空间"做梦"
  └→ PlaNet (2019)：潜空间规划
       └→ Dreamer (2020) → DreamerV2 (2021) → DreamerV3 (2023)
            └→ JEPA (LeCun)：从像素重建 → 特征空间预测
                 └→ Genie (Google 2024)：可操控生成式世界模型
                      └→ 当前前沿：机器人专用世界模型 · UniSim
```

**LLM → Agent 演进**
```
GPT-3 (2020)：涌现 → InstructGPT (2022)：对齐
  └→ ChatGPT 时代：工具调用 / Function Calling
       └→ ReAct (2022)：推理 + 行动交替
            └→ Reflexion (2023)：自我反思进化
                 └→ 当前前沿：多智能体协作 (AutoGen/CrewAI) · 长程记忆 · 自主 Agent
```

---

## 模块二：经典与前沿书籍

### 2.1 数学与机器学习基础

| 书名 | 作者/版本 | 核心价值 | 链接 | 难度 |
|-----|---------|---------|-----|------|
| Reinforcement Learning: An Introduction | Sutton & Barto · 2nd ed, 2018 | **RL 圣经**：MDP、TD 学习、函数近似全讲透，你的主攻必读 | [免费PDF](http://incompleteideas.net/book/the-book.html) | 入门→进阶 |
| Deep Learning | Goodfellow, Bengio, Courville · 2016 | DL 最系统教材，数学推导严谨，BP/CNN/RNN/生成模型全覆盖 | [免费HTML](https://www.deeplearningbook.org/) | 进阶 |
| Dive into Deep Learning (D2L) | 李沐等 · 持续更新 | **代码驱动**，中文友好，每章都有可运行的 PyTorch 代码 | [d2l.ai](https://d2l.ai/), [中文版](https://zh.d2l.ai/) | 入门→进阶 |
| Pattern Recognition and Machine Learning | Bishop · 2006 | 贝叶斯视角，数学最扎实，ML 理论基础的天花板参考 | 购买或图书馆 | 进阶 |
| Introduction to Linear Algebra | Gilbert Strang · 5th ed | 线代直觉培养首选，MIT OCW 配套视频极佳 | [OCW课程](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) | 入门 |

### 2.2 机器人学与具身智能

| 书名 | 作者/版本 | 核心价值 | 链接 | 难度 |
|-----|---------|---------|-----|------|
| Modern Robotics | Lynch & Park · 2017 | 运动学/动力学最清晰的现代教材，有免费 PDF 和配套课程 | [免费PDF](https://modernrobotics.northwestern.edu/) | 入门→进阶 |
| Probabilistic Robotics | Thrun, Burgard, Fox · 2005 | SLAM/定位/建图的数学基础，具身导航方向必读 | [MIT Press](https://mitpress.mit.edu/9780262201629/) | 进阶 |
| Robot Modeling and Control | Spong et al. · 2nd ed | 控制论视角，与你机械工程背景契合 | 购买 | 进阶 |

### 2.3 多智能体系统

| 书名 | 作者/版本 | 核心价值 | 难度 |
|-----|---------|---------|------|
| Multi-Agent Systems: Algorithmic, Game-Theoretic and Logical Foundations | Shoham & Leyton-Brown · 2009 | **MARL 理论基础**：博弈论视角，理解 MADDPG/QMIX 背后的数学 | 进阶 |
| An Introduction to MultiAgent Systems | Wooldridge · 2nd ed, 2009 | Agent 架构与协调的经典入门 | 入门 |

### 2.4 跨学科必读（建立认知框架）

| 书名 | 作者 | 核心价值 | 难度 |
|-----|-----|---------|------|
| Thinking, Fast and Slow | Daniel Kahneman | System 1/2 理论：理解 AI 决策机制与认知偏差的哲学基础 | 入门 |
| The Society of Mind | Marvin Minsky · 1986 | 模块化智能的先驱，做 MARL 读它你会有不同的视角 | 入门 |
| Gödel, Escher, Bach | Douglas Hofstadter | 自指、意识与递归：做 AI 研究的思维底座，慢读 | 进阶 |

---

## 模块三：未来必备技能图谱

### 3.1 硬技能体系

**编程语言（按当前优先级排序）**

| 语言 | 你当前应用场景 | 学习重点 | 推荐资源 |
|-----|------------|---------|---------|
| **Python** | RL/MARL/Agent/所有 ML 实验 | `asyncio` · `Pydantic` · `multiprocessing` · PyTorch 源码阅读 | [官方文档](https://docs.python.org/3/) |
| **C++** | ROS 2 节点 / 实时控制 / Isaac Lab 插件 | 指针/内存管理 · STL · 实时系统约束 · ROS 2 rclcpp | [learncpp.com](https://www.learncpp.com/) |
| **Rust** | 高性能推理 / 边缘部署 / 机器人低延迟系统 | 所有权系统 · `tokio` 异步 · `PyO3`（Python绑定） | [Rust Book](https://doc.rust-lang.org/book/) |

> **对你的建议**：Python 现在深耕，C++ 下半年开始，Rust 明年再看。

**数学基础（按紧迫度排序）**

| 方向 | 关键概念 | 与 RL/AI 的关联 | 紧迫度 |
|-----|---------|--------------|------|
| **概率论与数理统计** | 贝叶斯推断 · MDP · 期望/方差 · 随机过程 · 信息论 | **RL 的数学命门**：值函数本质是期望，策略梯度本质是方差控制 | ⭐⭐⭐⭐⭐ |
| 线性代数 | 特征分解 · SVD · 矩阵运算 · 向量空间 | 神经网络计算的本质是矩阵变换 | ⭐⭐⭐⭐ |
| 凸优化 | 梯度下降 · 拉格朗日 · KKT · 随机优化 | 所有深度学习训练的理论基础 | ⭐⭐⭐⭐ |
| 微分几何 | 流形 · 李群 · 切空间 | 机器人运动学建模（现在不急） | ⭐⭐ |

> ⚠️ **重点提示**：下学期的《概率论与数理统计》对你的 RL 路线直接决定性，必须把它学扎实。这门课是你从 DQN 走到策略梯度、从单 Agent 走到 MARL 的数学通行证。

**框架与工具（按主线优先级）**

| 工具/框架 | 用途 | 你的优先级 | 官方文档 |
|---------|-----|---------|---------|
| **PyTorch** | 深度学习全栈，手写 RL 算法基础 | ⭐⭐⭐⭐⭐ 最高 | [pytorch.org/docs](https://pytorch.org/docs/) |
| **PettingZoo** | MARL 环境标准接口，你的下一步 | ⭐⭐⭐⭐⭐ 当前 | [pettingzoo.farama.org](https://pettingzoo.farama.org/) |
| **MuJoCo** | 物理仿真，连续控制 RL 标准平台 | ⭐⭐⭐⭐ 暑假 | [mujoco.org](https://mujoco.org/) |
| **ROS 2** | 机器人中间件，工程化具身 AI 必须 | ⭐⭐⭐⭐ 下学期 | [docs.ros.org](https://docs.ros.org/) |
| **Isaac Lab** | NVIDIA 机器人仿真，具身 AI 当前标准 | ⭐⭐⭐⭐ 下半年 | [isaac-sim.github.io/IsaacLab](https://isaac-sim.github.io/IsaacLab/) |
| **TensorBoard** | 训练可视化，你已在用 | ⭐⭐⭐⭐ 保持 | — |
| **Docker** | 环境复现，论文 reproduce 必备 | ⭐⭐⭐ | [docs.docker.com](https://docs.docker.com/) |
| Git/GitHub | 版本控制，你已有日更习惯 ✅ | ⭐⭐⭐⭐⭐ 保持 | — |

---

### 3.2 软技能（比技术更难培养）

| 技能 | 具体含义 | 为何对你关键 |
|-----|---------|-----------|
| **问题定义** | 把"老年护理机器人"这个大目标，拆成一个可度量的研究问题 | 研究 / 创业最关键的第一步，你目前最缺的 |
| **技术写作** | 把实验结果写成可读的 CSDN 文章 / 论文 / GitHub README | 你已在做，继续坚持，这是你的差异化资产 |
| **批判性阅读** | 读论文时问：这个实验能复现吗？局限是什么？比较基线公平吗？| 别让论文忽悠，这是研究者的基本素养 |
| **跨学科协作** | 和医疗/心理/机械背景的人有效沟通 | 老年护理机器人是典型跨领域产品，你必须能和非 CS 背景的人说清楚 |
| **产品感** | 用你在 idea-forge / poke / JieZi 上积累的"用户为什么不用"的直觉 | 这是 AI 给不了你的东西，要主动培养 |

---

### 3.3 三种发展路径的能力侧重

| 路径 | 核心能力 | 典型产出 | 你的匹配度 |
|-----|---------|---------|----------|
| **研究型** | 数学推导 · 实验设计 · 创新性 · 论文写作 | 顶会论文 · 新算法 · 开源复现 | ⭐⭐⭐⭐ 打底 |
| **工程型** | 系统设计 · C++/ROS · 性能优化 · 部署 | 稳定运行的系统 · 开源项目 | ⭐⭐⭐ 实现层 |
| **产品/创业型** | 用户洞察 · 商业化 · 跨团队协作 · 融资叙事 | 公司 · 产品 · 收入 | ⭐⭐⭐⭐⭐ 你的终局 |

> 建议路径：**研究型打底 → 工程型实现 → 产品型变现**。你上传的那份指南说得对：不要急着跳到第三层。没有第一层，第三层是空中楼阁。

---

### 3.4 警惕的「伪需求技能」

| 伪需求 | 为何要警惕 | 建议 |
|-------|---------|-----|
| 过早深挖 Prompt Engineering | 模型升级会大幅贬值，技巧性大于理解性 | 理解 RLHF/ICL 原理即可，不要做技巧收集 |
| LangChain 全家桶精通 | 抽象层过深、调试地狱、版本更新混乱 | **先理解原理，再用框架**，避免不知道底下发生了什么 |
| 精通所有仿真平台 | Isaac Lab + Habitat + SAPIEN + Genesis = 全会但全不深 | **选 Isaac Lab 精通一个**，其余了解接口即可 |
| 过早学 Rust/C++ | 你现在最重要的是算法理解与实验能力 | 先 Python 跑通所有 RL 实验，再考虑性能优化 |
| 盲目追 SOTA | 每天刷 arXiv 看最新 paper 但不深读 | 一篇读透 > 十篇扫过，选对论文比追量更重要 |

---

## 模块四：开源生态与项目实战

### 4.1 Agent 框架（你的 LLM Agent 方向）

| 项目 | 核心价值 | GitHub | 难度 |
|-----|---------|--------|------|
| **LangGraph** | 有状态 Agent 工作流，支持循环/分支/人机协作，生产级 | [langchain-ai/langgraph](https://github.com/langchain-ai/langgraph) | 进阶 |
| **AutoGen** | 微软出品：多 Agent 对话协作框架，Research → Product 闭环 | [microsoft/autogen](https://github.com/microsoft/autogen) | 进阶 |
| **CrewAI** | 角色扮演式多 Agent 协作，易上手，适合快速原型 | [crewAIInc/crewAI](https://github.com/crewAIInc/crewAI) | 入门 |
| **MetaGPT** | 软件公司仿真：PM/工程师/测试 Agent 协作，国产明星项目 🇨🇳 | [geekan/MetaGPT](https://github.com/geekan/MetaGPT) | 进阶 |
| **AgentScope** | 阿里出品，分布式 Agent，中文文档完整 🇨🇳 | [modelscope/agentscope](https://github.com/modelscope/agentscope) | 进阶 |
| **CAMEL** | 角色扮演 Agent 研究，KAUST 出品，大量 MARL × LLM 论文支撑 | [camel-ai/camel](https://github.com/camel-ai/camel) | 进阶 |
| **Dify** | 开源 Agent 应用构建平台，可视化工作流，快速产品化 | [langgenius/dify](https://github.com/langgenius/dify) | 入门 |

---

### 4.2 具身仿真平台

| 平台 | 核心价值 | GitHub | 适合场景 |
|-----|---------|--------|---------|
| **Isaac Lab** (NVIDIA) | RTX 加速 · 超高并行度 · 机器人 RL 当前标准平台 | [isaac-sim/IsaacLab](https://github.com/isaac-sim/IsaacLab) | RL 控制 / 模仿学习 |
| **MuJoCo** (DeepMind) | 最精确物理仿真，RL 连续控制经典测试床 | [google-deepmind/mujoco](https://github.com/google-deepmind/mujoco) | 连续控制 / SAC 实验 |
| **Habitat 3.0** (Meta) | 室内导航 / 社交机器人 / 人形机器人仿真 | [facebookresearch/habitat-sim](https://github.com/facebookresearch/habitat-sim) | 导航 / 人机交互 |
| **SAPIEN** (UCSD) | 关节体精确仿真，操控任务标准平台 | [haosulab/SAPIEN](https://github.com/haosulab/SAPIEN) | 机械臂操控 |
| **Genesis** | 2024 新兴超高速物理仿真，速度远超 Isaac | [Genesis-Embodied-AI/Genesis](https://github.com/Genesis-Embodied-AI/Genesis) | 前沿探索（⚠️生产稳定性待验证） |
| **PettingZoo** | MARL 环境标准接口，Gymnasium 的多智能体版本 | [Farama-Foundation/PettingZoo](https://github.com/Farama-Foundation/PettingZoo) | **你的当前下一步** |

---

### 4.3 具身基础模型与 VLA

| 项目 | 核心价值 | GitHub | 难度 |
|-----|---------|--------|------|
| **LeRobot** (HuggingFace) | 机器人学习一站式工具箱，含 SO-100 低成本硬件配套 | [huggingface/lerobot](https://github.com/huggingface/lerobot) | 进阶 |
| **OpenVLA** | 开源 VLA 基准，7B，可消费级 GPU 微调，论文可直接复现 | [openvla/openvla](https://github.com/openvla/openvla) | 前沿 |
| **Stable Baselines 3** | 标准 RL 算法实现库，PPO/SAC/TD3 质量极高 | [DLR-RM/stable-baselines3](https://github.com/DLR-RM/stable-baselines3) | 入门 |
| **CLIP** (OpenAI) | 视觉语言对比学习，VLA 感知基础 | [openai/CLIP](https://github.com/openai/CLIP) | 入门 |

---

### 4.4 你的实战复现路线（按当前阶段）

```
📍 你现在的位置
   ✅ Q-Learning / FrozenLake（完成）
   ✅ DQN / CartPole 收敛（完成，arXiv 论文 + CSDN + GitHub）

🎯 阶段一（暑假，6月底-8月）
   → MARL：PettingZoo Simple Spread（合作）+ MADDPG 手写实现
   → MARL：PettingZoo Simple Tag（竞争）+ MAPPO 对比实验
   → 写一篇 CSDN 对比分析：MADDPG vs MAPPO 在合作任务上的表现

🎯 阶段二（下学期初，9-10月）
   → MuJoCo HalfCheetah/Ant 连续控制（SAC）
   → Isaac Lab 四足机器人站立/行走任务
   → 目标：把 RL 实验从离散动作空间推进到连续控制

🎯 阶段三（下学期后半，11月-明年）
   → Diffusion Policy 论文复现（操控基础）
   → LeRobot 上跑通一个 VLA 微调实验（条件：有 GPU）
   → 建立你自己的 MARL × 具身 benchmark（你的毕设/创业方向原型）
```

---

## 模块五：多媒体与开发者平台

### 5.1 体系化课程

**中文资源** 🇨🇳

| 资源 | 核心价值 | 链接 | 难度 |
|-----|---------|-----|------|
| 李宏毅机器学习 (2024) | 最好的中文 ML 课，每年更新，覆盖 Diffusion/LLM/RL | [B站](https://space.bilibili.com/1567748478) ⚠️请搜索"李宏毅"确认最新主页 | 入门 |
| 跟李沐学AI | 论文精读 + D2L 代码课，工程感极强 | [B站](https://space.bilibili.com/1567748478) 搜索"李沐" | 进阶 |
| 蘑菇书 EasyRL | 深度 RL 中文教程，Colab 可直接运行 🇨🇳 | [GitHub](https://github.com/datawhalechina/easy-rl) | 入门 |
| Datawhale 开源课程 | 系列 AI 教程，社区活跃 🇨🇳 | [github.com/datawhalechina](https://github.com/datawhalechina) | 入门 |

**英文资源**

| 资源 | 核心价值 | 链接 | 难度 |
|-----|---------|-----|------|
| **Karpathy: Neural Networks Zero to Hero** | 从 0 手写 GPT，理解 LLM 内核最好的资源，没有之一 | [YouTube](https://www.youtube.com/playlist?list=PLAqhIrjkxbuWI23v9cThsA9GvCAUhRvKZ) | 入门→进阶 |
| **David Silver RL Course (UCL)** | DeepMind 前科学家亲授，RL 理论最系统课程 | [YouTube](https://www.youtube.com/playlist?list=PLzuuYNsE1EZAXYR4FJ75jcJseBmo4KQ9-) | 进阶 |
| Pieter Abbeel CS 287 (Berkeley) | 机器人学习顶级课程，Abbeel 是 MARL + 模仿学习大牛 | 搜索 `"Pieter Abbeel CS287 lectures"` | 进阶 |
| Two Minute Papers | 顶会论文每周速览，保持前沿感知 | [YouTube](https://www.youtube.com/@TwoMinutePapers) | 入门 |
| Yannic Kilcher | 顶会论文深度解读，含批判性分析，不只是复述 | [YouTube](https://www.youtube.com/@YannicKilcher) | 进阶 |

---

### 5.2 国内大模型 API 与开发平台 🇨🇳

| 平台 | 核心优势 | 链接 | 适合你的场景 |
|-----|---------|-----|------------|
| **DeepSeek** | 最强推理，API 价格极低，代码/数学能力强 | [deepseek.com](https://www.deepseek.com/) | 算法开发 · 论文阅读辅助 · 每日研究 |
| **通义千问 (Qwen)** | Qwen2.5 系列可靠，多模态，模型开源可本地部署 | [tongyi.aliyun.com](https://tongyi.aliyun.com/) | 工程开发 · 本地部署实验 |
| **智谱 AI (GLM)** | 学生友好，有免费额度，多模态能力强 | [zhipuai.cn](https://www.zhipuai.cn/) | 学生实验 · API 调试 |
| **MiniMax** | 超长上下文，Agent 场景表现好 | [minimaxi.com](https://www.minimaxi.com/) | JieZi / Agent 项目开发 |
| **Dify** | 开源 Agent 构建平台，可视化工作流，产品化快 | [dify.ai](https://dify.ai/) | 快速验证产品原型 |
| **Coze** | 字节出品，Agent 编排，免费额度充足 | [coze.cn](https://www.coze.cn/) | 快速原型 · 轻量产品 |

---

### 5.3 Newsletter 与播客

| 资源 | 核心价值 | 链接 |
|-----|---------|-----|
| The Batch (Andrew Ng) | 每周 AI 前沿速递，有深度点评，质量稳定 | [deeplearning.ai/the-batch](https://www.deeplearning.ai/the-batch/) |
| Import AI (Jack Clark) | OpenAI 前政策主任，政策 + 技术视角，信噪比高 | [jack-clark.net](https://jack-clark.net/) |
| Ahead of AI (Sebastian Raschka) | 每篇都有 2000+ 字技术分析，深度压过广度 | [magazine.sebastianraschka.com](https://magazine.sebastianraschka.com/) |
| HuggingFace Daily Papers | 每日最新 arXiv 论文精选，含摘要 | [huggingface.co/papers](https://huggingface.co/papers) |
| NeurIPS/ICML 顶会视频 | 顶会 Talk 最新研究第一手资料 | [slideslive.com](https://slideslive.com/) |

---

### 5.4 社区与核心学者

**平台**

| 平台 | 用途 | 链接 |
|-----|-----|-----|
| **Papers With Code** | 论文 + 代码 + SOTA 榜单，每天刷 | [paperswithcode.com](https://paperswithcode.com/) |
| **Hugging Face** | 模型/数据集/Spaces，AI 开发中心 | [huggingface.co](https://huggingface.co/) |
| **Connected Papers** | 可视化论文关联图谱，找相关工作必备 | [connectedpapers.com](https://www.connectedpapers.com/) |
| **Semantic Scholar** | 论文引用追踪，找某个方向所有重要工作 | [semanticscholar.org](https://www.semanticscholar.org/) |
| **知乎「具身智能」话题** 🇨🇳 | 中文深度讨论，有大量国内从业者 | 关注「具身智能」「多智能体强化学习」话题 |

**值得关注的学者（Twitter/X）**

| 学者 / 机构 | 方向 | 账号 |
|------------|-----|-----|
| Yann LeCun | JEPA · 世界模型 · 自主机器智能 | @ylecun |
| Pieter Abbeel | 机器人学习 · MARL · 模仿学习 | @pabbeel |
| Sergey Levine | 具身 AI · 离线 RL · 数据驱动机器人 | @svlevine |
| Chelsea Finn | 元学习 · 机器人泛化 | @chelseabfinn |
| Google DeepMind | RT 系列 · Gemini 机器人 | @GoogleDeepMind |
| Physical Intelligence | π₀ 通用机器人 | @pi_robot |
| HuggingFace | LeRobot · 模型开源生态 | @huggingface |

**国内关注** 🇨🇳
- **具身智能之心**（公众号）：国内具身 AI 第一手资讯，质量高
- **新智元**（公众号）：AI 日报，覆盖广，信噪比中等
- **量子位**（公众号）：国内 AI 商业化动态

---

## 模块六：盲区补充与持续进化方法论

### 6.1 你可能遗漏但未来 3 年关键的方向

| 方向 | 为何关键 | 切入点 |
|-----|---------|------|
| **数据引擎与合成数据** | VLA 训练需要海量机器人数据，数据比算法更稀缺。谁掌握数据，谁领先 | 学 NVIDIA Omniverse 合成数据 · 了解 RoboAgent 数据增强 |
| **小模型与端侧部署** | 机器人不能依赖云端，本地推理延迟 < 100ms 是硬约束 | TensorRT · ONNX · 量化剪枝 · 你的机械工程背景有优势 |
| **机械可解释性（Mech Interp）** | 理解 Transformer 内部电路，AI Safety 的技术基础 | Anthropic 的 Transformer Circuits 系列文章 |
| **AI 安全与对齐** | 老年护理机器人必须是"可信 AI"，政策和技术都在快速演进 | 读 Anthropic/DeepMind Safety 博客 · 了解 RLHF/Constitutional AI |
| **神经符号 AI** | 纯深度学习泛化性弱，符号推理补足 System 2 能力，MARL 规划方向重要 | Minsky 的想法 + 当前 LLM + 工具调用的结合点 |
| **多模态感知融合** | 老年护理机器人需要视觉 + 触觉 + 语音的统一表征 | CMU 触觉传感论文 · Meta 手套传感器研究 |
| **机器人硬件成本曲线** | 低成本硬件（SO-100 < $100）将使具身 AI 普及速度超预期 | 关注 LeRobot · 大疆 RoboMaster 生态 |

---

### 6.2 针对你的差异化建议

**你拥有的三层护城河（你上传的指南总结得很准）**

1. **硬件 × 软件 × AI 三栖**：Arduino 焊板经验 + RL 算法实现 + LLM Agent 开发，这个组合极稀有
2. **真实产品经验**：idea-forge / poke / JieZi 不是作业，是有真实用户的产品，你懂"产品为什么不好用"
3. **机械工程背景**：理解物理约束、运动学、材料，这是 CS 背景同学补不回来的

**你需要特别注意的坑**

1. **不要用"学更多知识"作为不动手的理由**——这是你最根深蒂固的规划内卷模式
2. **每个新方向先跑通 Hello World**：MARL 先跑通 Simple Spread，不要先读 40 篇 survey
3. **保持一个可展示的 GitHub 项目**：比读 100 篇论文更有说服力，你已有这个习惯，继续
4. **找东华大学里做机器人的老师**：早进一个组，哪怕做边缘工作，接触真实硬件系统

---

### 6.3 持续跟踪 AI 前沿的方法论

**arXiv 订阅策略（只选这四个，否则信息过载）**

```
cs.AI   → 人工智能
cs.RO   → 机器人学（你的具身方向）
cs.LG   → 机器学习（算法层）
cs.MA   → 多智能体系统（你的 MARL 方向）

工具：
  arXiv Sanity Preserver → http://www.arxiv-sanity.com/
  Connected Papers      → https://www.connectedpapers.com/
  Semantic Scholar       → https://www.semanticscholar.org/
  HF Daily Papers       → https://huggingface.co/papers
```

**论文速读三步法**

```
第一遍（5分钟）—— 值不值得读？
  → Abstract + Conclusion + 主图/架构图
  → 判断：这篇是否与你当前主线相关？

第二遍（20分钟）—— 读懂核心
  → Introduction（问题是什么，为什么现有方法不行）
  → Method 核心图（架构图/算法框图）
  → Experiments 主结果表（比什么好，好多少）

第三遍（1小时+，仅精读论文）—— 吃透
  → 数学推导（一行行推）
  → 实现细节（看 Appendix）
  → 找 Limitations（这是创新点的来源）
  → 找可复现/可改进点 → 写进你的 GitHub issue
```

**个人知识体系（你已有工具，优化使用方式）**

```
你现有工具链：
  Obsidian（已有）  → 论文笔记 / 关键图谱 / 每日日记
  GitHub（已有）   → 代码实验 / 日更 ✅
  CSDN（已有）     → 技术输出 / 巩固理解

建议新增：
  Zotero           → 论文引用管理（免费，可与 Obsidian 联动）
  notion.so        → 项目看板（你已通过 MCP 在用）

输出倒逼输入原则：
  读完一篇重要论文 → 写 CSDN/知乎文章（哪怕 500 字）
  跑完一个实验    → push GitHub + 更新 README
  每周做一次复盘   → 5行写进 Obsidian Journal
  
  没有输出 = 没学到 ← 这是你自己定的规则
```

---

## 附录：你的下一步清单

```
考试结束后立即启动（6月24日后）：

P1（暑假核心任务）：
  □ PettingZoo 环境搭建 + Simple Spread 合作任务
  □ 手写 MADDPG（逐行注释）→ GitHub push → CSDN 文章
  □ MAPPO 对比实验 → 写成对比分析报告

P2（暑假探索）：
  □ MuJoCo 安装 + Ant 连续控制（SAC）
  □ 读完 DreamerV3 论文（世界模型方向基础）
  □ 阅读 MADDPG + QMIX 原始论文，推一遍数学推导

P3（长线积累，随时可做）：
  □ 订阅 arXiv cs.RO + cs.MA，建立每周 paper review 习惯
  □ 在东华找一个机器人相关实验室 → 联系老师
  □ 把 idea-forge / JieZi 中的 Multi-Agent 部分与学术 MARL 框架对齐，写一篇博客
  □ 概率论下学期：把 MDP 的数学推导反复做直到背推
```

---

*v1.0 · 2026.06 · 为陈韬定制*  
*所有 arXiv 链接在知识截止日前已验证，标注「⚠️待验证」的请自行确认 · 建议每半年更新本文档*
